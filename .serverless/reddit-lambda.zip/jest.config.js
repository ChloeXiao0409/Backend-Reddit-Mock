module.exports = {
    setupFilesAfterEnv: ['./tests/setup.js'],
    preset: "@shelf/jest-mongodb",
}